# password_generator/__init__.py

# Import the password generator function to expose it at the package level
from .passgen import password 

# Define package metadata
__version__ = "1.0.0"
__author__ = "Daniel Wangari"
